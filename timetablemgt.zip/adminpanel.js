//toggle up and down icon
function menus(){
    var x;
    var y;
    y = document.getElementById("me2");
    x = document.getElementById("me");
    x.style.display= "none";
    y.style.display= "inline";
              }
    
              function menuss(){
                var w;
                var z;
                w = document.getElementById("me2");
                z =  document.getElementById("me");
                w.style.display= "none";
                z.style.display= "inline";
              }

//panel menu arrow toggle for select Semester and add course
function arrowUp(){
  var x;
  var y;
  y = document.getElementById("arrow1");
  x = document.getElementById("arrow2");
  x.style.display= "none";
  y.style.display= "inline";
            }
  
            function arrowDown(){
              var w;
              var z;
              w = document.getElementById("arrow1");
              z =  document.getElementById("arrow2");
              w.style.display= "none";
              z.style.display= "inline";
            }

